from gui import main

print "\n\nCreating object"
easy_hybrid = main.EasyHybridMain()
easy_hybrid.run()


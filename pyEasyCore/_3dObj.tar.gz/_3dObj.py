#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  Main.py
#  
#  Copyright 2014 Fernando Bachega <fernando@bachega>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  

""" OpenGL Zoom Pan Rotate Widget for PyGTK
    subclass or otherwise assign a 'draw' function to an instance of this class
    The draw gets called back each time it should render
    The OpenGL context has been set up so you can just draw with naked gl* func
    Optionally, provide a 'pick' function to get callbacks when the user clicks
    on an object that has been named with glPushNames()

    translation of the excellent GLT ZPR (Zoom Pan Rotate) C code:
    http://www.nigels.com/glt/gltzpr/
    Released under LGPL: http://www.gnu.org/copyleft/lesser.html
    (c) William Edwards 2010
"""

#  https://sites.google.com/site/williamedwardscoder/zoompanrotate-opengl-in-python
#  


import pygtk; pygtk.require('2.0')
try:
	import gtk, gtk.gdk as gdk, gtk.gtkgl as gtkgl, gtk.gdkgl as gdkgl
except:
	print "try: sudo apt-get install  python-gtkglext1"
	
	
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *

import OpenGL.GL as gl
import OpenGL.arrays.vbo as glvbo


import sys
import numpy as np
import numpy.random as rdn

#import math
#from numpy import matrix
#from pdb import *
#from vector_math import *
#from AtomColors import _ATOMCOLORS
#from AtomTypes import *



class rotacao_mouse(object):
    _instance   = None
    em_execucao = False
    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(rotacao_mouse, cls).__new__(
                                cls, *args, **kwargs)
        return cls._instance

class GLZPR(gtkgl.DrawingArea):
	def __init__(self,w=640,h=480):
		try:
			glconfig = gdkgl.Config(mode = (gdkgl.MODE_RGB|gdkgl.MODE_DOUBLE|gdkgl.MODE_DEPTH))
		except gtk.gdkgl.NoMatches:
			glconfig = gdkgl.Config(mode = (gdkgl.MODE_RGB|gdkgl.MODE_DEPTH))
		
		gtkgl.DrawingArea.__init__(self,glconfig)
		self.set_size_request(w,h)
		self.connect_after("realize",self._init)
		self.connect("configure_event",     self._reshape)
		self.connect("expose_event",        self._draw)
		self.connect("button_press_event",  self._mouseButton)
		self.connect("button_release_event",self._mouseButton)
		self.connect("motion_notify_event", self._mouseMotion)
		self.connect("scroll_event",        self._mouseScroll)
		self.set_flags(gtk.HAS_FOCUS | gtk.CAN_FOCUS)
		
		#self.connect('key_press_event', self.key_cb)
		self.set_events(self.get_events()|gdk.BUTTON_PRESS_MASK|gdk.BUTTON_RELEASE_MASK|
			gdk.POINTER_MOTION_MASK|gdk.POINTER_MOTION_HINT_MASK|gtk.gdk.KEY_PRESS_MASK)

		#self.add_events(gtk.gdk.KEY_PRESS_MASK)
		#self.connect('key_press_event', self.key_cb)
		self.scroll = 1.0
		self.zero = {"1" : [ 1.504,   1.692,   1.344],
				     "2" : [ 1.900,   1.136,   0.048],
				     "3" : [ 3.040,   1.976,  -0.532],
				     "4" : [ 3.480,   2.944,   0.084],
				     "5" : [ 0.684,   1.140,  -0.900],
				     "6" : [-0.492,   0.304,  -0.416],
				     "7" : [-1.580,   0.920,   0.240],
				     "8" : [-0.500,  -1.092,  -0.620],
				     "9" : [-2.672,   0.140,   0.688],
				     "10":[-1.588,  -1.868,  -0.172],
				     "11":[-2.672,  -1.252,   0.480],
				     "12":[ 3.516,   1.596,  -1.720],
				     "13":[ 0.820,   2.420,   1.208],
				     "14":[ 2.248,   0.104,   0.184],
				     "15":[ 2.284,   2.064,   1.868],
				     "16":[ 1.008,   0.748,  -1.872],
				     "17":[ 0.344,   2.180,  -1.016],
				     "18":[-1.580,   1.992,   0.404],
				     "19":[ 0.336,  -1.568,  -1.124],
				     "20":[-3.504,   0.616,   1.192],
				     "21":[-1.588,  -2.940,  -0.332],
				     "22":[-3.512,  -1.848,   0.824],
				     "23":[ 1.156,   0.864,   1.800]
				     }
		
		x_total = 0
		y_total = 0
		z_total = 0
		for i in self.zero:
			x = self.zero[i][0]
			y = self.zero[i][1]
			z = self.zero[i][2]
			x_total = x_total + x
			y_total = y_total + y			
			z_total = z_total + z			
		
		x_total = x_total/23
		y_total = y_total/23		
		z_total = z_total/23		
		self._zprReferencePoint = [0.,0.,0.,0.]
		self.MassReferencePoint = [x_total,y_total,z_total,0.]
		
		
			
		self._zNear, self._zFar = -10.0, 10.0
		self._mouseX = self._mouseY = 0
		self._dragPosX = self._dragPosY = self._dragPosZ = 0.



		self._mouseRotate = self._mouseZoom = self._mousePan = self._mousePan2 = False
	
	def put_center2 (self):
		glColor3f(0.5, .5, 0.5)
		glPushMatrix()
		glTranslate(0,0, 0)
		glutSolidSphere(10.0, 50, 50)
		#gluSphere(quadratic, 0.8, 50, 50)
		#gluDeleteQuadric(quadratic)
		#glDisable(Gl.GL_CLIP_PLANE0)
		glPopName()
		#eqn = [0.0, 1.0, 0.0, 0.72]
		#glClipPlane(GL_CLIP_PLANE0, eqn)
		self.queue_draw()
		print 'aqui '
		
	def put_center (self):
		#self._zprReferencePoint = [-2.914 ,  3.797,  -0.460, 0.]
		with self.open_context(True):
			viewport = glGetIntegerv(GL_VIEWPORT)
			print viewport
			glLoadIdentity()
			#glOrtho(-20,30, 20,-20, -20,20)

			#gluLookAt(0,  0,  0, -2.914 ,  3.797,  -0.460, 10,  10,  10)
			##glOrtho(-10,  10,  -10,  10.0 ,  -10.0,  10.0)
			changed = True
			glPushMatrix()
			glPopMatrix()
			if changed:
				self.queue_draw()
		with self.open_context(False):
			pass
			
	class _Context:
		def __init__(self,widget):
			self._widget = widget
			self._count = 0
			self._modelview = self._projection = None
			self._persist = False
		
		def __enter__(self):
			#pass
			assert(self._count == 0)
			self.ctx = gtkgl.widget_get_gl_context(self._widget)
			self.surface = gtkgl.widget_get_gl_drawable(self._widget)
			self._begin = self.surface.gl_begin(self.ctx)
			if self._begin:
				self._count += 1
				if self._projection is not None:
					glMatrixMode(GL_PROJECTION)
					glLoadMatrixd(self._projection)
				if self._modelview is not None:
					glMatrixMode(GL_MODELVIEW)
					glLoadMatrixd(self._modelview)
				return self
			return
		
		def __exit__(self,exc_type,exc_value,exc_traceback):
			if self._begin:
				self._count -= 1
				if self._persist and (exc_type is None):
					self._modelview = glGetDoublev(GL_MODELVIEW_MATRIX)
					self._projection = glGetDoublev(GL_PROJECTION_MATRIX)
				self.surface.gl_end()
			del self.ctx
			del self.surface
			self._persist = False
			if exc_type is not None:
				import traceback
				traceback.print_exception(exc_type,exc_value,exc_traceback)
			return True # suppress
			
	def open_context(self,persist_matrix_changes = False):
		if not hasattr(self,"_context"):
			self._context = self._Context(self)
		assert(self._context._count == 0)
		self._context._persist = persist_matrix_changes
		return self._context
		
	def get_open_context(self):
		if hasattr(self,"_context") and (self._context._count > 0):
			return self._context
		
	def _init(self,widget):
		assert(widget == self)
		self.init() ### optionally overriden by subclasses
		return True
		
	def reset(self):
		with self.open_context(True):
			glMatrixMode(GL_MODELVIEW)
			glLoadIdentity()
				  
	def init(self):
		pass
		#glLightfv(GL_LIGHT0,GL_AMBIENT, (1.,1.,1.,0.))
		glLightfv(GL_LIGHT0,GL_DIFFUSE, (1.,1.,1.,0.))
		glLightfv(GL_LIGHT0,GL_SPECULAR,(1.,1.,1.,0.))
		glLightfv(GL_LIGHT0,GL_POSITION,(100.,0.,0.,1.))
		#glMaterialfv(GL_FRONT,GL_AMBIENT, (.7,.7,.7,1.))
		#glMaterialfv(GL_FRONT,GL_DIFFUSE, (.8,.8,.8,1.))
		#glMaterialfv(GL_FRONT,GL_SPECULAR,(1.,1.,1.,1.))
		glMaterialfv(GL_FRONT,GL_SHININESS,100.0)
		glShadeModel(GL_SMOOTH)
		glEnable(GL_LIGHTING)
		glEnable(GL_LIGHT0)
		#glDepthFunc(GL_LESS)
		glEnable(GL_DEPTH_TEST)
		glEnable(GL_NORMALIZE)
		glEnable(GL_COLOR_MATERIAL)
		
		#glPushMatrix()
		glLightfv(GL_LIGHT0,GL_AMBIENT, (1.,1.,1.,0.))
		glLightfv(GL_LIGHT0,GL_DIFFUSE, (1.,1.,1.,0.))
		glLightfv(GL_LIGHT0,GL_SPECULAR,(1.,1.,1.,0.))
		glLightfv(GL_LIGHT0,GL_POSITION,(0.,100.,0.,1.))
		glMaterialfv(GL_FRONT,GL_SHININESS,100.0)

	def _reshape(self,widget,event):
		assert(self == widget) 
		with self.open_context(True):
			x, y, width, height = self.get_allocation()
			glViewport(0,0,width,height);
			self._top    =  1.0
			self._bottom = -1.0
			self._left   = -float(width)/float(height)
			self._right  = -self._left
			glMatrixMode(GL_PROJECTION)
			glLoadIdentity()
			glOrtho(self._left,self._right,self._bottom,self._top,self._zNear,self._zFar)
		if hasattr(self,"reshape"):
			self.reshape(event,x,y,width,height) ### optionally implemented by subclasses
		return True
		
	def _mouseMotion(self,widget,event):
		
		
		#print "aqui"
		#auxiliar = rotacao_mouse()
		#if auxiliar.em_execucao:
		#	return
		#print "aqui2"
		#auxiliar.em_execucao = True

		assert(widget==self)
		
		
		if event.is_hint:
			x, y, state = event.window.get_pointer()
		else:
			x = event.x
			y = event.y
			state = event.state
		dx = x - self._mouseX
		dy = y - self._mouseY
		if (dx==0 and dy==0): return
		self._mouseX, self._mouseY = x, y
		
		with self.open_context(True):
			changed = False
			
			if self._mouseZoom:
				s = math.exp(float(dy)*0.01)
				self._apply(glScalef,s,s,s)
				changed = True

			elif self._mouseRotate:
				ax, ay, az = dy, dx, 0.
				viewport = glGetIntegerv(GL_VIEWPORT)
				#print 'viewport', viewport
				angle = math.sqrt(ax**2+ay**2+az**2)/float(viewport[2]+1)*180.0
				inv = matrix(glGetDoublev(GL_MODELVIEW_MATRIX)).I

				bx = inv[0,0]*ax + inv[1,0]*ay + inv[2,0]*az
				by = inv[0,1]*ax + inv[1,1]*ay + inv[2,1]*az
				bz = inv[0,2]*ax + inv[1,2]*ay + inv[2,2]*az
				
				self._apply(glRotatef,angle,bx,by,bz)
				
				changed = True
				#glMatrixMode(GL_MODELVIEW)
				#glLoadIdentity()
				glPushMatrix()

				glPopMatrix()

			elif self._mousePan:
				#print 'coco'
				px, py, pz = self._pos(x,y);
				modelview = glGetDoublev(GL_MODELVIEW_MATRIX)
				glLoadIdentity()
				glTranslatef(px-self._dragPosX,py-self._dragPosY,pz-self._dragPosZ)
				glMultMatrixd(modelview)
				self._dragPosX = px
				self._dragPosY = py
				self._dragPosZ = pz
				changed = True

			elif self._mousePan2:
				px, py, pz = self._pos(x,y);
				modelview = glGetDoublev(GL_MODELVIEW_MATRIX)
				glLoadIdentity()
				glTranslatef(px-self._dragPosX,py-self._dragPosY,pz-self._dragPosZ)
				glMultMatrixd(modelview)
				self._dragPosX = px
				self._dragPosY = py
				self._dragPosZ = pz
				changed = True


			if changed:
				self.queue_draw()
			
			#auxiliar.em_execucao = False
			
	def _apply(self,func,*args):
		glTranslatef(*self._zprReferencePoint[0:3])
		func(*args)
		glTranslatef(*map(lambda x:-x,self._zprReferencePoint[0:3]))

	def _mouseScroll(self,widget,event):
		assert(self == widget)       
		
		if event.direction == gdk.SCROLL_UP:
			s =  0.05
		if event.direction == gdk.SCROLL_DOWN:
			s = -0.05
		
		
		self.scroll = self.scroll + s 
		print self.scroll
		if self.scroll <= 0 :
			self.scroll = 0.001
			return True
			
		#s = math.exp(s*0.01)
		
		with self.open_context(True):
			
			#glLoadIdentity()
			#eqn =  [ 0.0 , 0.0,  1.0, self.scroll]
			#eqn2 = [-1.5 , 0.0, -0.5, self.scroll]
			#eqnK = [ 1.0 , 0.0,  1.0, 0.40]
			#
			#glClipPlane(GL_CLIP_PLANE0, eqn)
			#glEnable   (GL_CLIP_PLANE0)
			
			
			#glClipPlane(GL_CLIP_PLANE1, eqn2)
			#glEnable   (GL_CLIP_PLANE1)
			#glClipPlane(GL_CLIP_PLANE2, eqnK)
			#glEnable   (GL_CLIP_PLANE2)
			
			#glGetIntegerv(GL_VIEWPORT, ViewPort)
			#glMatrixMode(GL_PROJECTION)
			#glPushMatrix()
			#glLoadIdentity()
			#glOrtho(0, ViewPort[2], 0, ViewPort[3], -100, 100)
			#glMatrixMode(GL_MODELVIEW)
			#glPushMatrix()
			#glLoadIdentity();
			
			#glLoadIdentity()
			#glMatrixMode(GL_PROJECTION)
			#glOrtho (-1, 1, -1, 1, 0.1, -0.1 )
			#print s
			#self._applyself.scroll(glScalef,s,s,s)
			#self._apply(glPointSize,s)
			
			x, y, width, height = self.get_allocation()
			glViewport(0,0,width,height);
			self._top    =  1.0
			self._bottom = -1.0
			self._left   = -float(width)/float(height)
			self._right  = -self._left
			glMatrixMode(GL_PROJECTION)
			glLoadIdentity()
			glOrtho(self._left,self._right,self._bottom, self._top, -self.scroll, self.scroll)
			
			
			self.queue_draw()
		
		
		
		
		
		
		
		#assert(self == widget)       
		#s = 0.01 if (event.direction == gdk.SCROLL_UP) else -0.01
		#s = math.exp(s*0.01)
		#
		#with self.open_context(True):
		#	#self._apply(glFrustum,s, 2*s, 3*s,  s,  -s,  2*s)
		#	#self._apply(glOrtho,s, 2*s, 3*s,  s,  -s,  2*s)
		#	self.queue_draw()		
		#	print "gordo"


	@classmethod 
	# Eles servem pra alterar o comportamento das nossas funcoes/metodos/classes de diversas maneiras. 
	# Nos nossos exemplos ai, o primeiro decorator faz com que o nosso metodo receba a classe e nao a
	# instancia como primeiro parametro, e no segundo (@property), faz com que chamemos nosso metodo 
	# como se fosse um atributo, e se tentarmos fazer uma atribuicao a isso, vai dar erro.
				 
	def event_masked(cls,event,mask):
		return (event.state & mask) == mask

	@classmethod
	def _button_check(cls,event,button,mask):
		# this shouldn't be so crazy complicated
		if event.button == button:
			return (event.type == gdk.BUTTON_PRESS)                    
		return cls.event_masked(event,mask) 
		
	@classmethod
	def get_left_button_down(cls,event):
		return cls._button_check(event,1,gdk.BUTTON1_MASK)   # return  True or False
			                                                 
	@classmethod                                             
	def get_middle_button_down(cls,event):                   
		return cls._button_check(event,2,gdk.BUTTON2_MASK)   # return  True or False

	@classmethod
	def get_right_button_down(cls,event):
		return cls._button_check(event,3,gdk.BUTTON3_MASK)   # return  True or False
	
	
	
		
	def _mouseButton(self,widget,event):
		left   = self.get_left_button_down(event)
		middle = self.get_middle_button_down(event)
		right  = self.get_right_button_down(event)
        
		#print event
		
		self._mouseRotate = left  and not (middle or right)

		self._mouseZoom   = right and not (middle or left) #middle or (left and right)
		
		self._mousePan    = middle and not (right or left) #right and self.event_masked(event,gdk.SHIFT_MASK) #right and self.event_masked(event,gdk.CONTROL_MASK)
		
		self._mousePan2   = left and self.event_masked(event,gdk.CONTROL_MASK)

		
		
		#self._mouseRotate = left  and not (middle or right)
        #
		#self._mouseZoom   = middle or (left and right)
		#
		#self._mousePan    = right and self.event_masked(event,gdk.SHIFT_MASK) #right and self.event_masked(event,gdk.CONTROL_MASK)
		#
		#self._mousePan2   = left  and self.event_masked(event,gdk.CONTROL_MASK)
				
		
		test              = middle and self.event_masked(event,gdk.SHIFT_MASK)
		

		# was it a multiple click?
		'''
		if event.type == gtk.gdk.BUTTON_PRESS:
			print "single click"
		if event.type == gtk.gdk._2BUTTON_PRESS:
			print "double click"
		if event.type == gtk.gdk._3BUTTON_PRESS:
			print "triple click. ouch, you hurt your user."
		'''
		
		
	
		
		x = self._mouseX = event.x
		y = self._mouseY = event.y
		self._dragPosX, self._dragPosY, self._dragPosZ = self._pos(x,y)                          
		
		#if event.type == gtk.gdk.BUTTON_PRESS:
		#	widget.popup(None, None, None, event.button, event.time)
		
		
		#------------------------------------------------------------------------------#
		if event.button == 1 and event.type == gtk.gdk._2BUTTON_PRESS:                 #
			nearest, hits =	self._pick(x,self.get_allocation().height-1-y,3,3,event)   #      # Double Click left button 
			self.pick(event,nearest,hits) # None if nothing hit                        #                                                                 
		#------------------------------------------------------------------------------#
		
		if test:
			with self.open_context():                                                            
				nearest, hits =	self._pick(x,self.get_allocation().height-1-y,3,3,event)         
				self.pick(event,nearest,hits) # None if nothing hit                              
				
		                                                                                          
		#-----------------------------------------------------------------------------------------#                                                                                          
		if self._mousePan2:                                                                       #   modificado por mim 
			#print "gostosao"                                                                     #
			with self.open_context():                                                             #
				nearest, hits =	self._pick(x,self.get_allocation().height-1-y,3,3,event)          #
				self.pick(event,nearest,hits) # None if nothing hit                               #
		#-----------------------------------------------------------------------------------------#	                                                                                      
                                                                                                  
                                                                                                  
		
		#if (left and not self.event_masked(event,gdk.CONTROL_MASK)) and hasattr(self,"pick"):    #
		#	with self.open_context():                                                             #
		#		nearest, hits = \                                                                 #  codigo fonte original - faz o pick sem apertar o ctrl junto
		#			self._pick(x,self.get_allocation().height-1-y,3,3,event)                      #
		#		self.pick(event,nearest,hits) # None if nothing hit                               #
		                                                                                          #
		self.queue_draw()
		
	def pick(self,event,nearest,hits):
		#if nearest != []:
		print "picked", nearest
		#print self.zero[str(nearest[0])]
		##print hits.names
		#for hit in hits:
		#	print hit.near, hit.far, hit.names


		if nearest != []:
			x = self.zero[str(nearest[0])][0]
			y = self.zero[str(nearest[0])][1]
			z = self.zero[str(nearest[0])][2]
			self._zprReferencePoint = [x,  y,   z, 0.]
		else:
			print "bola"
			self._zprReferencePoint = self.MassReferencePoint
			
	def _pos(self,x,y):
		"""
		Use the ortho projection and viewport information
		to map from mouse co-ordinates back into world
		co-ordinates
		"""  
		viewport = glGetIntegerv(GL_VIEWPORT)
		px = float(x-viewport[0])/float(viewport[2])
		py = float(y-viewport[1])/float(viewport[3])       
		px = self._left + px*(self._right-self._left)
		py = self._top  + py*(self._bottom-self._top)
		pz = self._zNear
		return (px,py,pz)
		
	def _pick(self,x,y,dx,dy,event):
		buf = glSelectBuffer(256)
		glRenderMode(GL_SELECT)
		glInitNames()
		glMatrixMode(GL_PROJECTION)
		glPushMatrix() # remember projection matrix
		viewport = glGetIntegerv(GL_VIEWPORT)
		projection = glGetDoublev(GL_PROJECTION_MATRIX)
		glLoadIdentity()
		gluPickMatrix(x,y,dx,dy,viewport)
		glMultMatrixd(projection)        
		glMatrixMode(GL_MODELVIEW)
		glPushMatrix()
		self.draw(event)
		glPopMatrix()
		
		hits = glRenderMode(GL_RENDER) #buf = GL.glRenderMode(GL.GL_RENDER)
		#hits = glRenderMode(GL_SELECT)
		
		nearest = []
		minZ = None
		
		for hit in hits:
			#print hit
		
			if (len(hit.names) > 0) and \
			((minZ is None) or (hit.near < minZ)):
				minZ = hit.near
				nearest = hit.names #[-1]
				
		glMatrixMode(GL_PROJECTION)
		glPopMatrix() # restore projection matrix 
		glMatrixMode(GL_MODELVIEW)
		#self.put_center2
		#a = glReadPixels()
		#print a
		return (nearest, hits)

	def _draw(self,widget,event):
		assert(self == widget)   
		with self.open_context() as ctx:
			glMatrixMode(GL_MODELVIEW)
			self.draw(event) ### implemented by subclasses
			if ctx.surface.is_double_buffered():
				ctx.surface.swap_buffers()
			else:
				glFlush()
		return True

class obj_3d():
	
    def __init__ (self):#(self, molecules):
        """ Function doc """
        self.molecules = None

        self.data = np.array(.2*rdn.randn(100000,2),dtype=np.float32)
        self.set_data(self.data)

    def set_data(self, data):
        """Load 2D data as a Nx2 Numpy array.
        """
        self.data =  data
        self.count = data.shape[0]
 
    def initializeGL(self):
        """Initialize OpenGL, VBOs, upload data on the GPU, etc.
        """
        # background color
        data = np.array(.2*rdn.randn(100000,2),dtype=np.float32)
        gl.glClearColor(0,0,0,0)
        # create a Vertex Buffer Object with the specified data
        self.vbo = glvbo.VBO(data)
 
    def paintGL(self):
        """Paint the scene.
        """
        # clear the buffer
        gl.glClear(gl.GL_COLOR_BUFFER_BIT)
        # set yellow color for subsequent drawing rendering calls
        gl.glColor(1,1,0)            
        # bind the VBO 
        self.vbo.bind()
        # tell OpenGL that the VBO contains an array of vertices
        gl.glEnableClientState(gl.GL_VERTEX_ARRAY)
        # these vertices contain 2 single precision coordinates
        gl.glVertexPointer(2, gl.GL_FLOAT, 0, self.vbo)
        # draw "count" points from the VBO
        gl.glDrawArrays(gl.GL_POINTS, 0, self.count)
 
    def resizeGL(self, width, height):
        """Called upon window resizing: reinitialize the viewport.
        """
        # update the window size
        self.width, self.height = width, height
        # paint within the whole window
        gl.glViewport(0, 0, width, height)
        # set orthographic projection (2D only)
        gl.glMatrixMode(gl.GL_PROJECTION)
        gl.glLoadIdentity()
        # the window corner OpenGL coordinates are (-+1, -+1)
        gl.glOrtho(-1, 1, -1, 1, -1, 1)
        
    def _demo_draw(self, event):
	    
        self.initializeGL()
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
#
#	def _demo_draw(self, event):
#		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
#		#glClearColor(0.7, 0.7, 0.7, 1.0)     # -  CLARO
#		glClearColor(0.01, 0.01, 0.01, 1.0)   # -  ESCURO		
#		for m in self.molecules:
#			#print "molecule name is: %s" % m.name
#			for key in m.atoms.keys():
#
#				a = m.atoms[key]
#				#self.DrawAtom(a , key)
#				#self.DrawAtomPoint(a, key)
#			
#			for bond in m.bonds:
#				point_a = m.atoms[bond.atom_id_1].pos
#				point_b = m.atoms[bond.atom_id_2].pos
#				aSymbol = m.atoms[bond.atom_id_1].symbol
#				bSymbol = m.atoms[bond.atom_id_2].symbol
#				
#				if bond.type == 'single':
#					cylinder_radius = 0.05
#				if bond.type == 'double':
#					cylinder_radius = 0.15
#				else:
#					cylinder_radius = 0.10
#				
#				
#				#self.DrawBond(point_a,point_b, cylinder_radius )
#				self.DrawBondLines(point_a, point_b, aSymbol, bSymbol)
#		
#	def GetAtomColor (self, symbol):
#		factor= 25.0
#		color = atypes[symbol][3]
#		return color
#	
#	def DrawAtom (self, a, key):
#		""" draw a atom as a sphere """
#		color = self.GetAtomColor(a.symbol)
#		glColor3f(color[0],  color[1],  color[2]) # grey
#
#		if a.symbol == "H":
#			atom_size = .25
#		else:
#			atom_size = .4
#		
#		glPushMatrix()
#
#		glTranslate(float(a.pos[0]),float( a.pos[1]), float(a.pos[2]))
#		
#		glPushName(int(key))                    # nome da esfera = int ex. 1,2,4,5
#		glutSolidSphere(atom_size, 15, 15)
#		
#
#
#
#		glPopName()                             # importante para o vetor nao estourar
#		glPopMatrix()                     
#		glFlush()
#
#	def DrawBond (self, a, b, radius):
#		v = Vector()
#		#base of cylinder is at the origin, the top is in the positive z axis
#		axis_start = [0, 0, .1]
#		#
#		axis_end = v.subtract(a, b)
#		
#		#find angle between the starting and ending axis
#		angle = v.angle(axis_start, axis_end)
#		
#		
#		# determina the axis of rotation of the angle
#		axis_rotation = v.crossproduct (axis_start, axis_end)
#		
#		#calculate the distance from a to b
#		
#		length = v.mag(axis_end)
#		glColor3f(0.9, 0.9, 0.9)
#		
#		# set the bottom  and the top radius to be the same thing
#		radius_bottom = radius
#		radius_top =  radius
#		
#		# draw the bond ( use glTranslate beofre using glRotate)
#		cyl = gluNewQuadric()
#		glPushMatrix()
#
#		glTranslate(b[0], b[1], b[2])
#		#glPushName(0)
#		glRotate(angle, axis_rotation[0], axis_rotation[1], axis_rotation[2])
#		gluCylinder(cyl, radius_bottom, radius_top, length, 15, 15)
#		glPopMatrix()
#
#	def DrawAtomPoint (self, a, key):
#		""" draw a atom as a sphere """
#		color = self.GetAtomColor(a.symbol)
#		glColor3f(color[0],  color[1],  color[2]) # grey
#
#		if a.symbol == "H":
#			atom_size = .25
#		else:
#			atom_size = .4
#		
#		glPushName(int(key))
#		glPushMatrix()		
#		#glPointSize(10.0)
#		#gluDisk(1, 0,1, 1, 2)
#		#glBegin( GL_POINTS)	
#		#glVertex3f (float(a.pos[0]),float( a.pos[1]), float(a.pos[2]) )		
#		#glEnd( )		
#		glPopName() 
#		glPopMatrix()
#		#glPointSize(1.0)
#
#	def DrawBondLines (self, a, b , aSymbol, bSymbol):
#		v = Vector()
#		#base of cylinder is at the origin, the top is in the positive z axis
#		axis_start = [0, 0, .1]
#		
#		#
#		axis_end = v.subtract(a, b)
#		
#		#find angle between the starting and ending axis
#		angle = v.angle(axis_start, axis_end)
#		
#		
#		# determina the axis of rotation of the angle
#		axis_rotation = v.crossproduct (axis_start, axis_end)
#		
#		#calculate the distance from a to b
#		
#		length = v.mag(axis_end)
#		glLineWidth(2.5)
#		glPushMatrix()
#		
#		''' calculating the middle point between the two bonds'''
#		ix,iy,iz = a[0], a[1], a[2]
#		jx,jy,jz = b[0], b[1], b[2]		
#		
#		mx = 0.5 * ( ix + jx )
#		my = 0.5 * ( iy + jy )		
#		mz = 0.5 * ( iz + jz )		
#		
#		''' Atom 1 - importing colors'''
#
#		glPushName(1)                    # nome da esfera = int ex. 1,2,4,5
#		color = self.GetAtomColor(aSymbol)
#		glColor3f(color[0],  color[1],  color[2]) # grey		
#		
#		glBegin( GL_LINES )		
#		glVertex3f ( ix, iy, iz )		
#		glVertex3f ( mx, my, mz )		
#		                            # importante para o vetor nao estourar
#		glEnd( )		
#		glPopName() 
#		''' Atom 2 - importing colors'''
#		glPushName(2) 
#		color = self.GetAtomColor(bSymbol)
#		glColor3f(color[0],  color[1],  color[2]) # grey
#		
#
#		glBegin( GL_LINES )
#		glVertex3f ( mx, my, mz )		
#		glVertex3f ( jx, jy, jz )		
#		
#		glEnd( )
#		glPopName()		
#		glPopMatrix()
#	
#	def DrawCaRibbon (self, a, b, radius):
#		v = Vector()
#		#base of cylinder is at the origin, the top is in the positive z axis
#		axis_start = [0, 0, .1]
#		#
#		axis_end = v.subtract(a, b)
#		
#		#find angle between the starting and ending axis
#		angle = v.angle(axis_start, axis_end)
#		
#		
#		# determina the axis of rotation of the angle
#		axis_rotation = v.crossproduct (axis_start, axis_end)
#		
#		#calculate the distance from a to b
#		
#		length = v.mag(axis_end)
#		glColor3f(0.9, 0.9, 0.9)
#		# set the bottom  and the top radius to be the same thing
#		radius_bottom = radius
#		radius_top =  radius
#		# draw the bond ( use glTranslate beofre using glRotate)
#		cyl = gluNewQuadric()
#		glPushMatrix()
#		#glLoadIdentity()
#		#glTranslate(0,0,-10)
#		#glRotate(self.auto_rotation_angle, 1, 1, 1)
#		glTranslate(b[0], b[1], b[2])
#		glRotate(angle, axis_rotation[0], axis_rotation[1], axis_rotation[2])
#		gluCylinder(cyl, radius_bottom, radius_top, length, 5, 5)
#		glPopMatrix()

if __name__ == '__main__':
	import sys
	#glutInit(sys.argv)                         # indica que a glut vai usar o gerenciador de janelas do sistema
	glutInit([])
	#glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB)
	#glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB)
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH)

	gtk.gdk.threads_init()
	window = gtk.Window(gtk.WINDOW_TOPLEVEL)
	window.set_title("Zoom Pan Rotate")
	window.set_size_request(800,800)
	window.connect("destroy",lambda event: gtk.main_quit())
	vbox = gtk.VBox(False, 0)
	window.add(vbox)
	zpr = GLZPR()
	zpr.reset

	a = [0.5, 0.4, 0.5]
	#importando as infos dos pdbs
	#path = '/home/fernando/Documents/emol/sample/gly.pdb'
	#path = 'new_pdb_step1.pdb'
	#path = "pep.pdb"
	path = 'phe.pdb'	
	
	molecules1 = Pdb(path).molecules
	OBJ_3d1 = obj_3d(molecules1)
	
	#molecules2 = Pdb(path2).molecules
	#OBJ_3d2 = obj_3d(molecules2)
	
	zpr.draw = OBJ_3d1._demo_draw
	vbox.pack_start(zpr,True,True)
	window.show_all()
	
	#glutLookAt(-2.914 ,  3.797,  -0.460, -2.914 ,  3.797,  -0.460, 10.0, 10.0, 10.0)
    
	for name in (GL_VENDOR,GL_RENDERER,GL_SHADING_LANGUAGE_VERSION,GL_EXTENSIONS):
		print name,glGetString(name)
	
	print "\n\nCreating object"
	print glGetString(GL_VERSION)
	print glGetString(GL_RENDERER)
	print glGetString(GL_VENDOR)
	print "\n\n"
	gtk.main()

